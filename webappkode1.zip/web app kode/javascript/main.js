/*
 * Searching for users matching the input value
 */
function search(value) {
    value = value.toLowerCase(); //for at input altid bliver læst med småt
    console.log(value);

    const results = [];

    for (const user of _users) {
        const name = user.name.toLowerCase();

        if (name.includes(value)) {
            results.push(user);
        }
    }

    console.log(results);

    appendUsers(results);
};