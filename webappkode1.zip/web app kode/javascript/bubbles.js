"use strict";

function appendBubbles(styles) {
  let html = ""; // laver en variabel for at holde dataen i den

  for (const style of styles) {
    html += /*html*/`
          <div class="bubble" onclick="navigateTo('#/shuffle')">
            <h2>${user.styles}</h2>
          </div>
        `;
  };
  document.querySelector("#bubbles_container").innerHTML = html;
};
