/**
 * All routes of the SPA
 * "path": "id of page in DOM"
 */
const _routes = {
    "#/": "velkommen",
    "#/opret": "opret",
    "#/guide": "guide",
    "#/forside": "forside",
};

const _pages = document.querySelectorAll(".page");
const _basePath = location.pathname.replace("index.html", ""); // remove "index.html" from path
const _navLinks = document.querySelectorAll("nav a"); // VÆR OBS PÅ DIV BOX I TOP TABBAR

/**
 * Changing display to none for all pages
 */
function hideAllPages() {
    for (const page of _pages) {
        page.style.display = "none";
    }
}

/**
 * Navigating SPA to specific page by given path
 */
function navigateTo(path) {
    window.history.pushState({}, path, _basePath + path);
    showPage(path);
}

/**
 * Displaying page by given path
 */
function showPage(path) {

    if (path == "#/shuffle") { // user is authenticated: 
        showTabbar(true); // then show tabbar
    }
    else { // if user NOT authenticated: 
        path = "#velkommen"; // then change path to #/login,
        window.history.pushState({}, path, _basePath + path); // set pushState with new path
        showTabbar(false); // and hide the tabbar
    }

    hideAllPages(); // hide all pages
    document.querySelector(`#${_routes[path]}`).style.display = "block"; // show page by path

};

/**
 * Attaching event to nav links and preventing default anchor link event
 */
function attachNavLinkEvents() {
    const navLinks = document.querySelectorAll(".nav-link");
    for (const link of navLinks) {
        link.addEventListener("click", function (event) {
            const path = link.getAttribute("href");
            navigateTo(path);
            event.preventDefault();
        });
    }
}

/**
 * Initialising the router, calling attachNavLinkEvents(), popstate event and navigateTo()
 */
function initRouter() {
    attachNavLinkEvents();
    window.addEventListener("popstate", () => showPage(location.hash)); // change page when using back and forth in browser

    let path = "#/velkommen"; // default path
    if (_routes[location.hash]) {
        path = location.hash;
    }
    navigateTo(path);
}

initRouter();

// show and hide tabbars
function showTabbar(show) {
    let tabbarTop = document.querySelector('.tabbarTop');
    if (show) {
        tabbarTop.classList.remove("hide");
    } else {
        tabbarTop.classList.add("hide");
    }
}
// show and hide tabbars
function showTabbar(show) {
    let tabbarTop = document.querySelector('.tabbarBottom');
    if (show) {
        tabbarBottom.classList.remove("hide");
    } else {
        tabbarBottom.classList.add("hide");
    }
}

// function showTabbar(show) {
//     let tabbarBottom = document.querySelector('.tabbarBottom');
//     if (show) {
//         tabbar.classList.remove("hide");
//     } else {
//         tabbar.classList.add("hide");
//     }
// }