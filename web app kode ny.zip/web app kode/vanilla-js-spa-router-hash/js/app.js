import "./router.js";
console.log("app.js is running!");